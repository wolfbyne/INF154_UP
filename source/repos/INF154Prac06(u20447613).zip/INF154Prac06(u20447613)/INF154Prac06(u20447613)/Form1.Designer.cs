﻿namespace INF154Prac06_u20447613_
{
    partial class frm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbPlayer1 = new System.Windows.Forms.GroupBox();
            this.lblM1 = new System.Windows.Forms.Label();
            this.lblST1 = new System.Windows.Forms.Label();
            this.lblMultiple1 = new System.Windows.Forms.Label();
            this.lblSum1 = new System.Windows.Forms.Label();
            this.lblOutputTRN1 = new System.Windows.Forms.Label();
            this.lblTRN1 = new System.Windows.Forms.Label();
            this.gbPlayer2 = new System.Windows.Forms.GroupBox();
            this.lblM2 = new System.Windows.Forms.Label();
            this.lblST2 = new System.Windows.Forms.Label();
            this.lblOutputTRN2 = new System.Windows.Forms.Label();
            this.lblMultiple2 = new System.Windows.Forms.Label();
            this.lblSum2 = new System.Windows.Forms.Label();
            this.lblTRN2 = new System.Windows.Forms.Label();
            this.btnPlay = new System.Windows.Forms.Button();
            this.lblWTC = new System.Windows.Forms.Label();
            this.lblWM4 = new System.Windows.Forms.Label();
            this.lblWinnerOutput = new System.Windows.Forms.Label();
            this.lblMultipleOutput = new System.Windows.Forms.Label();
            this.lbPlayer1 = new System.Windows.Forms.ListBox();
            this.lbPlayer2 = new System.Windows.Forms.ListBox();
            this.gbPlayer1.SuspendLayout();
            this.gbPlayer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbPlayer1
            // 
            this.gbPlayer1.Controls.Add(this.lblM1);
            this.gbPlayer1.Controls.Add(this.lblST1);
            this.gbPlayer1.Controls.Add(this.lblMultiple1);
            this.gbPlayer1.Controls.Add(this.lblSum1);
            this.gbPlayer1.Controls.Add(this.lblOutputTRN1);
            this.gbPlayer1.Controls.Add(this.lblTRN1);
            this.gbPlayer1.Location = new System.Drawing.Point(29, 38);
            this.gbPlayer1.Name = "gbPlayer1";
            this.gbPlayer1.Size = new System.Drawing.Size(226, 112);
            this.gbPlayer1.TabIndex = 0;
            this.gbPlayer1.TabStop = false;
            this.gbPlayer1.Text = "Player 1 Stats";
            // 
            // lblM1
            // 
            this.lblM1.AutoSize = true;
            this.lblM1.Location = new System.Drawing.Point(158, 83);
            this.lblM1.Name = "lblM1";
            this.lblM1.Size = new System.Drawing.Size(37, 13);
            this.lblM1.TabIndex = 5;
            this.lblM1.Text = "output";
            // 
            // lblST1
            // 
            this.lblST1.AutoSize = true;
            this.lblST1.Location = new System.Drawing.Point(158, 55);
            this.lblST1.Name = "lblST1";
            this.lblST1.Size = new System.Drawing.Size(37, 13);
            this.lblST1.TabIndex = 4;
            this.lblST1.Text = "output";
            // 
            // lblMultiple1
            // 
            this.lblMultiple1.AutoSize = true;
            this.lblMultiple1.Location = new System.Drawing.Point(6, 83);
            this.lblMultiple1.Name = "lblMultiple1";
            this.lblMultiple1.Size = new System.Drawing.Size(67, 13);
            this.lblMultiple1.TabIndex = 3;
            this.lblMultiple1.Text = "Multiple of 4:";
            // 
            // lblSum1
            // 
            this.lblSum1.AutoSize = true;
            this.lblSum1.Location = new System.Drawing.Point(6, 55);
            this.lblSum1.Name = "lblSum1";
            this.lblSum1.Size = new System.Drawing.Size(70, 13);
            this.lblSum1.TabIndex = 2;
            this.lblSum1.Text = "Sum of Total:";
            // 
            // lblOutputTRN1
            // 
            this.lblOutputTRN1.AutoSize = true;
            this.lblOutputTRN1.Location = new System.Drawing.Point(158, 28);
            this.lblOutputTRN1.Name = "lblOutputTRN1";
            this.lblOutputTRN1.Size = new System.Drawing.Size(37, 13);
            this.lblOutputTRN1.TabIndex = 1;
            this.lblOutputTRN1.Text = "output";
            // 
            // lblTRN1
            // 
            this.lblTRN1.AutoSize = true;
            this.lblTRN1.Location = new System.Drawing.Point(6, 28);
            this.lblTRN1.Name = "lblTRN1";
            this.lblTRN1.Size = new System.Drawing.Size(122, 13);
            this.lblTRN1.TabIndex = 0;
            this.lblTRN1.Text = "Total Random Numbers:";
            // 
            // gbPlayer2
            // 
            this.gbPlayer2.Controls.Add(this.lblM2);
            this.gbPlayer2.Controls.Add(this.lblST2);
            this.gbPlayer2.Controls.Add(this.lblOutputTRN2);
            this.gbPlayer2.Controls.Add(this.lblMultiple2);
            this.gbPlayer2.Controls.Add(this.lblSum2);
            this.gbPlayer2.Controls.Add(this.lblTRN2);
            this.gbPlayer2.Location = new System.Drawing.Point(558, 38);
            this.gbPlayer2.Name = "gbPlayer2";
            this.gbPlayer2.Size = new System.Drawing.Size(226, 112);
            this.gbPlayer2.TabIndex = 1;
            this.gbPlayer2.TabStop = false;
            this.gbPlayer2.Text = "Player 2 Stats";
            // 
            // lblM2
            // 
            this.lblM2.AutoSize = true;
            this.lblM2.Location = new System.Drawing.Point(157, 83);
            this.lblM2.Name = "lblM2";
            this.lblM2.Size = new System.Drawing.Size(37, 13);
            this.lblM2.TabIndex = 9;
            this.lblM2.Text = "output";
            // 
            // lblST2
            // 
            this.lblST2.AutoSize = true;
            this.lblST2.Location = new System.Drawing.Point(157, 55);
            this.lblST2.Name = "lblST2";
            this.lblST2.Size = new System.Drawing.Size(37, 13);
            this.lblST2.TabIndex = 8;
            this.lblST2.Text = "output";
            // 
            // lblOutputTRN2
            // 
            this.lblOutputTRN2.AutoSize = true;
            this.lblOutputTRN2.Location = new System.Drawing.Point(157, 28);
            this.lblOutputTRN2.Name = "lblOutputTRN2";
            this.lblOutputTRN2.Size = new System.Drawing.Size(37, 13);
            this.lblOutputTRN2.TabIndex = 7;
            this.lblOutputTRN2.Text = "output";
            // 
            // lblMultiple2
            // 
            this.lblMultiple2.AutoSize = true;
            this.lblMultiple2.Location = new System.Drawing.Point(9, 83);
            this.lblMultiple2.Name = "lblMultiple2";
            this.lblMultiple2.Size = new System.Drawing.Size(67, 13);
            this.lblMultiple2.TabIndex = 6;
            this.lblMultiple2.Text = "Multiple of 4:";
            // 
            // lblSum2
            // 
            this.lblSum2.AutoSize = true;
            this.lblSum2.Location = new System.Drawing.Point(6, 55);
            this.lblSum2.Name = "lblSum2";
            this.lblSum2.Size = new System.Drawing.Size(70, 13);
            this.lblSum2.TabIndex = 6;
            this.lblSum2.Text = "Sum of Total:";
            // 
            // lblTRN2
            // 
            this.lblTRN2.AutoSize = true;
            this.lblTRN2.Location = new System.Drawing.Point(6, 28);
            this.lblTRN2.Name = "lblTRN2";
            this.lblTRN2.Size = new System.Drawing.Size(122, 13);
            this.lblTRN2.TabIndex = 6;
            this.lblTRN2.Text = "Total Random Numbers:";
            // 
            // btnPlay
            // 
            this.btnPlay.Location = new System.Drawing.Point(343, 183);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(125, 48);
            this.btnPlay.TabIndex = 10;
            this.btnPlay.Text = "Play Game";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // lblWTC
            // 
            this.lblWTC.AutoSize = true;
            this.lblWTC.Location = new System.Drawing.Point(303, 279);
            this.lblWTC.Name = "lblWTC";
            this.lblWTC.Size = new System.Drawing.Size(117, 13);
            this.lblWTC.TabIndex = 11;
            this.lblWTC.Text = "Winner for Total Count:";
            // 
            // lblWM4
            // 
            this.lblWM4.AutoSize = true;
            this.lblWM4.Location = new System.Drawing.Point(303, 332);
            this.lblWM4.Name = "lblWM4";
            this.lblWM4.Size = new System.Drawing.Size(119, 13);
            this.lblWM4.TabIndex = 12;
            this.lblWM4.Text = "Winner for Multiple of 4:";
            // 
            // lblWinnerOutput
            // 
            this.lblWinnerOutput.AutoSize = true;
            this.lblWinnerOutput.Location = new System.Drawing.Point(471, 279);
            this.lblWinnerOutput.Name = "lblWinnerOutput";
            this.lblWinnerOutput.Size = new System.Drawing.Size(37, 13);
            this.lblWinnerOutput.TabIndex = 13;
            this.lblWinnerOutput.Text = "output";
            // 
            // lblMultipleOutput
            // 
            this.lblMultipleOutput.AutoSize = true;
            this.lblMultipleOutput.Location = new System.Drawing.Point(471, 332);
            this.lblMultipleOutput.Name = "lblMultipleOutput";
            this.lblMultipleOutput.Size = new System.Drawing.Size(37, 13);
            this.lblMultipleOutput.TabIndex = 14;
            this.lblMultipleOutput.Text = "output";
            // 
            // lbPlayer1
            // 
            this.lbPlayer1.FormattingEnabled = true;
            this.lbPlayer1.Location = new System.Drawing.Point(30, 184);
            this.lbPlayer1.Name = "lbPlayer1";
            this.lbPlayer1.Size = new System.Drawing.Size(226, 316);
            this.lbPlayer1.TabIndex = 15;
            // 
            // lbPlayer2
            // 
            this.lbPlayer2.FormattingEnabled = true;
            this.lbPlayer2.Location = new System.Drawing.Point(559, 184);
            this.lbPlayer2.Name = "lbPlayer2";
            this.lbPlayer2.Size = new System.Drawing.Size(226, 316);
            this.lbPlayer2.TabIndex = 16;
            // 
            // frm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(815, 518);
            this.Controls.Add(this.lbPlayer2);
            this.Controls.Add(this.lbPlayer1);
            this.Controls.Add(this.lblMultipleOutput);
            this.Controls.Add(this.lblWinnerOutput);
            this.Controls.Add(this.lblWM4);
            this.Controls.Add(this.lblWTC);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.gbPlayer2);
            this.Controls.Add(this.gbPlayer1);
            this.Name = "frm1";
            this.Text = "Repitition";
            this.gbPlayer1.ResumeLayout(false);
            this.gbPlayer1.PerformLayout();
            this.gbPlayer2.ResumeLayout(false);
            this.gbPlayer2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbPlayer1;
        private System.Windows.Forms.Label lblM1;
        private System.Windows.Forms.Label lblST1;
        private System.Windows.Forms.Label lblMultiple1;
        private System.Windows.Forms.Label lblSum1;
        private System.Windows.Forms.Label lblOutputTRN1;
        private System.Windows.Forms.Label lblTRN1;
        private System.Windows.Forms.GroupBox gbPlayer2;
        private System.Windows.Forms.Label lblM2;
        private System.Windows.Forms.Label lblST2;
        private System.Windows.Forms.Label lblOutputTRN2;
        private System.Windows.Forms.Label lblMultiple2;
        private System.Windows.Forms.Label lblSum2;
        private System.Windows.Forms.Label lblTRN2;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Label lblWTC;
        private System.Windows.Forms.Label lblWM4;
        private System.Windows.Forms.Label lblWinnerOutput;
        private System.Windows.Forms.Label lblMultipleOutput;
        private System.Windows.Forms.ListBox lbPlayer1;
        private System.Windows.Forms.ListBox lbPlayer2;
    }
}

