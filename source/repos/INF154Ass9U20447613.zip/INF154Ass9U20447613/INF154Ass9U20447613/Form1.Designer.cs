﻿namespace INF154Ass9U20447613
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbFillAll = new System.Windows.Forms.GroupBox();
            this.btnFillAll = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.lblFillAll = new System.Windows.Forms.Label();
            this.txtC = new System.Windows.Forms.TextBox();
            this.gbMethods = new System.Windows.Forms.GroupBox();
            this.btnSquare = new System.Windows.Forms.Button();
            this.btnOdd = new System.Windows.Forms.Button();
            this.btnEven = new System.Windows.Forms.Button();
            this.btnSum = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblOdd = new System.Windows.Forms.Label();
            this.lblEven = new System.Windows.Forms.Label();
            this.lblSum = new System.Windows.Forms.Label();
            this.txtSquare = new System.Windows.Forms.TextBox();
            this.txtOdd = new System.Windows.Forms.TextBox();
            this.txtEven = new System.Windows.Forms.TextBox();
            this.txtSum = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblPlease = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.txtAnswerSum = new System.Windows.Forms.TextBox();
            this.txtAnswerEven = new System.Windows.Forms.TextBox();
            this.txtAnswerOdd = new System.Windows.Forms.TextBox();
            this.txtAnswerSquare = new System.Windows.Forms.TextBox();
            this.gbFillAll.SuspendLayout();
            this.gbMethods.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbFillAll
            // 
            this.gbFillAll.Controls.Add(this.btnFillAll);
            this.gbFillAll.Controls.Add(this.label12);
            this.gbFillAll.Controls.Add(this.lblFillAll);
            this.gbFillAll.Controls.Add(this.txtC);
            this.gbFillAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbFillAll.Location = new System.Drawing.Point(271, 38);
            this.gbFillAll.Name = "gbFillAll";
            this.gbFillAll.Size = new System.Drawing.Size(411, 112);
            this.gbFillAll.TabIndex = 0;
            this.gbFillAll.TabStop = false;
            this.gbFillAll.Text = "Fill All:";
            // 
            // btnFillAll
            // 
            this.btnFillAll.Location = new System.Drawing.Point(285, 57);
            this.btnFillAll.Name = "btnFillAll";
            this.btnFillAll.Size = new System.Drawing.Size(92, 26);
            this.btnFillAll.TabIndex = 13;
            this.btnFillAll.Text = "Fill All";
            this.btnFillAll.UseVisualStyleBackColor = true;
            this.btnFillAll.Click += new System.EventHandler(this.btnFillAll_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(95, 60);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(26, 20);
            this.label12.TabIndex = 12;
            this.label12.Text = "C:";
            // 
            // lblFillAll
            // 
            this.lblFillAll.AutoSize = true;
            this.lblFillAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFillAll.Location = new System.Drawing.Point(127, 31);
            this.lblFillAll.Name = "lblFillAll";
            this.lblFillAll.Size = new System.Drawing.Size(116, 16);
            this.lblFillAll.TabIndex = 1;
            this.lblFillAll.Text = "Fill All Text Boxes:";
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(127, 57);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(100, 26);
            this.txtC.TabIndex = 0;
            // 
            // gbMethods
            // 
            this.gbMethods.Controls.Add(this.txtAnswerSquare);
            this.gbMethods.Controls.Add(this.txtAnswerOdd);
            this.gbMethods.Controls.Add(this.txtAnswerEven);
            this.gbMethods.Controls.Add(this.txtAnswerSum);
            this.gbMethods.Controls.Add(this.btnSquare);
            this.gbMethods.Controls.Add(this.btnOdd);
            this.gbMethods.Controls.Add(this.btnEven);
            this.gbMethods.Controls.Add(this.btnSum);
            this.gbMethods.Controls.Add(this.label11);
            this.gbMethods.Controls.Add(this.label10);
            this.gbMethods.Controls.Add(this.label9);
            this.gbMethods.Controls.Add(this.lblC);
            this.gbMethods.Controls.Add(this.label8);
            this.gbMethods.Controls.Add(this.lblOdd);
            this.gbMethods.Controls.Add(this.lblEven);
            this.gbMethods.Controls.Add(this.lblSum);
            this.gbMethods.Controls.Add(this.txtSquare);
            this.gbMethods.Controls.Add(this.txtOdd);
            this.gbMethods.Controls.Add(this.txtEven);
            this.gbMethods.Controls.Add(this.txtSum);
            this.gbMethods.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbMethods.Location = new System.Drawing.Point(12, 189);
            this.gbMethods.Name = "gbMethods";
            this.gbMethods.Size = new System.Drawing.Size(790, 217);
            this.gbMethods.TabIndex = 1;
            this.gbMethods.TabStop = false;
            this.gbMethods.Text = "Methods";
            // 
            // btnSquare
            // 
            this.btnSquare.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSquare.Location = new System.Drawing.Point(641, 181);
            this.btnSquare.Name = "btnSquare";
            this.btnSquare.Size = new System.Drawing.Size(90, 30);
            this.btnSquare.TabIndex = 15;
            this.btnSquare.Text = "Square It!";
            this.btnSquare.UseVisualStyleBackColor = true;
            this.btnSquare.Click += new System.EventHandler(this.btnSquare_Click);
            // 
            // btnOdd
            // 
            this.btnOdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOdd.Location = new System.Drawing.Point(478, 181);
            this.btnOdd.Name = "btnOdd";
            this.btnOdd.Size = new System.Drawing.Size(75, 30);
            this.btnOdd.TabIndex = 14;
            this.btnOdd.Text = "Is Odd?";
            this.btnOdd.UseVisualStyleBackColor = true;
            this.btnOdd.Click += new System.EventHandler(this.btnOdd_Click);
            // 
            // btnEven
            // 
            this.btnEven.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEven.Location = new System.Drawing.Point(283, 181);
            this.btnEven.Name = "btnEven";
            this.btnEven.Size = new System.Drawing.Size(75, 30);
            this.btnEven.TabIndex = 13;
            this.btnEven.Text = "Is Even?";
            this.btnEven.UseVisualStyleBackColor = true;
            this.btnEven.Click += new System.EventHandler(this.btnEven_Click);
            // 
            // btnSum
            // 
            this.btnSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSum.Location = new System.Drawing.Point(114, 181);
            this.btnSum.Name = "btnSum";
            this.btnSum.Size = new System.Drawing.Size(75, 30);
            this.btnSum.TabIndex = 12;
            this.btnSum.Text = "Sum 1-C";
            this.btnSum.UseVisualStyleBackColor = true;
            this.btnSum.Click += new System.EventHandler(this.btnSum_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(610, 93);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(26, 20);
            this.label11.TabIndex = 11;
            this.label11.Text = "C:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(447, 93);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(26, 20);
            this.label10.TabIndex = 10;
            this.label10.Text = "C:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(251, 93);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 20);
            this.label9.TabIndex = 9;
            this.label9.Text = "C:";
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(83, 93);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(26, 20);
            this.lblC.TabIndex = 8;
            this.lblC.Text = "C:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(638, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "Square C!";
            // 
            // lblOdd
            // 
            this.lblOdd.AutoSize = true;
            this.lblOdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOdd.Location = new System.Drawing.Point(475, 48);
            this.lblOdd.Name = "lblOdd";
            this.lblOdd.Size = new System.Drawing.Size(63, 16);
            this.lblOdd.TabIndex = 6;
            this.lblOdd.Text = "Is It Odd?";
            // 
            // lblEven
            // 
            this.lblEven.AutoSize = true;
            this.lblEven.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEven.Location = new System.Drawing.Point(280, 48);
            this.lblEven.Name = "lblEven";
            this.lblEven.Size = new System.Drawing.Size(68, 16);
            this.lblEven.TabIndex = 5;
            this.lblEven.Text = "Is It Even?";
            // 
            // lblSum
            // 
            this.lblSum.AutoSize = true;
            this.lblSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSum.Location = new System.Drawing.Point(112, 48);
            this.lblSum.Name = "lblSum";
            this.lblSum.Size = new System.Drawing.Size(94, 16);
            this.lblSum.TabIndex = 4;
            this.lblSum.Text = "Sum of 1 To C:";
            // 
            // txtSquare
            // 
            this.txtSquare.Location = new System.Drawing.Point(642, 87);
            this.txtSquare.Name = "txtSquare";
            this.txtSquare.Size = new System.Drawing.Size(55, 26);
            this.txtSquare.TabIndex = 3;
            // 
            // txtOdd
            // 
            this.txtOdd.Location = new System.Drawing.Point(479, 87);
            this.txtOdd.Name = "txtOdd";
            this.txtOdd.Size = new System.Drawing.Size(55, 26);
            this.txtOdd.TabIndex = 2;
            // 
            // txtEven
            // 
            this.txtEven.Location = new System.Drawing.Point(283, 87);
            this.txtEven.Name = "txtEven";
            this.txtEven.Size = new System.Drawing.Size(55, 26);
            this.txtEven.TabIndex = 1;
            // 
            // txtSum
            // 
            this.txtSum.Location = new System.Drawing.Point(115, 87);
            this.txtSum.Name = "txtSum";
            this.txtSum.Size = new System.Drawing.Size(55, 26);
            this.txtSum.TabIndex = 0;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(34, 63);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 2;
            // 
            // lblPlease
            // 
            this.lblPlease.AutoSize = true;
            this.lblPlease.Location = new System.Drawing.Point(34, 38);
            this.lblPlease.Name = "lblPlease";
            this.lblPlease.Size = new System.Drawing.Size(158, 13);
            this.lblPlease.TabIndex = 4;
            this.lblPlease.Text = "Please Enter Your Name Below:";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(318, 412);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(228, 60);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(814, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(118, 20);
            this.toolStripMenuItem1.Text = "Welcome Message";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // txtAnswerSum
            // 
            this.txtAnswerSum.Enabled = false;
            this.txtAnswerSum.Location = new System.Drawing.Point(114, 136);
            this.txtAnswerSum.Name = "txtAnswerSum";
            this.txtAnswerSum.Size = new System.Drawing.Size(56, 26);
            this.txtAnswerSum.TabIndex = 16;
            // 
            // txtAnswerEven
            // 
            this.txtAnswerEven.Enabled = false;
            this.txtAnswerEven.Location = new System.Drawing.Point(283, 136);
            this.txtAnswerEven.Name = "txtAnswerEven";
            this.txtAnswerEven.Size = new System.Drawing.Size(56, 26);
            this.txtAnswerEven.TabIndex = 17;
            // 
            // txtAnswerOdd
            // 
            this.txtAnswerOdd.Enabled = false;
            this.txtAnswerOdd.Location = new System.Drawing.Point(478, 136);
            this.txtAnswerOdd.Name = "txtAnswerOdd";
            this.txtAnswerOdd.Size = new System.Drawing.Size(56, 26);
            this.txtAnswerOdd.TabIndex = 18;
            // 
            // txtAnswerSquare
            // 
            this.txtAnswerSquare.Enabled = false;
            this.txtAnswerSquare.Location = new System.Drawing.Point(642, 136);
            this.txtAnswerSquare.Name = "txtAnswerSquare";
            this.txtAnswerSquare.Size = new System.Drawing.Size(56, 26);
            this.txtAnswerSquare.TabIndex = 19;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 484);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lblPlease);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.gbMethods);
            this.Controls.Add(this.gbFillAll);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Homework 9";
            this.gbFillAll.ResumeLayout(false);
            this.gbFillAll.PerformLayout();
            this.gbMethods.ResumeLayout(false);
            this.gbMethods.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbFillAll;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblFillAll;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.GroupBox gbMethods;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblOdd;
        private System.Windows.Forms.Label lblEven;
        private System.Windows.Forms.Label lblSum;
        private System.Windows.Forms.TextBox txtSquare;
        private System.Windows.Forms.TextBox txtOdd;
        private System.Windows.Forms.TextBox txtEven;
        private System.Windows.Forms.TextBox txtSum;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblPlease;
        private System.Windows.Forms.Button btnFillAll;
        private System.Windows.Forms.Button btnSquare;
        private System.Windows.Forms.Button btnOdd;
        private System.Windows.Forms.Button btnEven;
        private System.Windows.Forms.Button btnSum;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.TextBox txtAnswerSquare;
        private System.Windows.Forms.TextBox txtAnswerOdd;
        private System.Windows.Forms.TextBox txtAnswerEven;
        private System.Windows.Forms.TextBox txtAnswerSum;
    }
}

